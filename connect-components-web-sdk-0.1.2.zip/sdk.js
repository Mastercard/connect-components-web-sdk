;(() => {
  e = (e = { APP_SDK_BASE: 'https://components.finicity.com/connect-components' }).APP_SDK_BASE
  var e = { sdkBase: (e = new URL(e)).toString(), frameOrigin: e.origin },
    t = ((e) => {
      let {
        appConfig: r,
        HTMLElement: t,
        crypto: i,
        logger: n,
        document: a,
        MutationObserver: s
      } = e
      return class extends t {
        constructor() {
          super(), (this.eventStream = null), (this.events = null)
        }
        connectedCallback() {
          var e = this.querySelector('mastercard-event-stream')
          e
            ? (this.eventStream = e)
            : this.getAttribute('event-stream-id')?.length &&
              ((e = this.getAttribute('event-stream-id')),
              (this.eventStream = a.createElement('mastercard-event-stream')),
              this.eventStream.setAttribute('event-stream-id', e),
              this.appendChild(this.eventStream),
              (this.events = this.eventStream.events)),
            (this.observer = new s(() => {
              Array.from(this.querySelectorAll('mastercard-input'))
                .filter((e) => e.getAttribute('form-id') !== this.id)
                .forEach((e) => {
                  e.setAttribute('form-id', this.id)
                }),
                Array.from(this.querySelectorAll('mastercard-mfa-choice'))
                  .filter((e) => e.getAttribute('form-id') !== this.id)
                  .forEach((e) => {
                    e.setAttribute('form-id', this.id)
                  })
            })),
            this.observer.observe(this, { subtree: !0, childList: !0, characterData: !1 })
        }
        onSubmit(e) {
          e.preventDefault(), this.submit()
        }
        submit() {
          var e = i.randomUUID(),
            t = r.sdkBase,
            e = { formId: this.getAttribute('id'), eventType: 'submitRequest', requestId: e }
          this.eventStream
            ? ((e.eventStreamId = this.eventStream.getAttribute('event-stream-id')),
              this.eventStream.querySelector('iframe').contentWindow.postMessage(e, t))
            : n.warn('No event stream registered!')
        }
      }
    })({
      appConfig: e,
      crypto: crypto,
      HTMLElement: HTMLElement,
      document: document,
      MutationObserver: MutationObserver,
      logger: console
    })
  var r = ((e) => {
    let r = e.Promise
    return function (t = 1) {
      return new r((e) => {
        setTimeout(() => {
          e(null)
        }, t)
      })
    }
  })({ Promise: Promise })
  var i = class {
      constructor() {
        ;(this._emitter = new EventTarget()),
          (this._eventData = new WeakMap()),
          (this._callbacks = new Map())
      }
      on(e, t) {
        var r = (e) => {
          t(this._eventData.get(e))
        }
        this._callbacks.has(e) || this._callbacks.set(e, new WeakMap()),
          this._callbacks.get(e).has(t) ||
            (this._callbacks.get(e).set(t, r), this._emitter.addEventListener(e, r))
      }
      off(e, t) {
        var r = this._callbacks.get(e)?.get(t)
        r && (this._emitter.removeEventListener(e, r), this._callbacks.get(e)?.delete(t))
      }
      emit(e, t) {
        e = new Event(e)
        this._eventData.set(e, t), this._emitter.dispatchEvent(e)
      }
    },
    n = ((e) => {
      let { HTMLElement: t, window: n, document: r, MastercardEventEmitter: i } = e
      return class extends t {
        constructor() {
          super(),
            (this.frameReady = !1),
            (this.innerFrame = r.createElement('iframe')),
            (this.emitter = new i()),
            (this.elemId = null),
            (this.formId = null),
            (this._hasChanged = !1)
        }
        addEventListener(e, t) {
          this.emitter.on(e, t)
        }
        removeEventListener(e, t) {
          this.emitter.off(e, t)
        }
        async attributeChangedCallback(e, t, r) {
          'id' === e && t !== r
            ? ((this.elemId = this.getAttribute('id')), (this._hasChanged = !0))
            : 'form-id' === e &&
              t !== r &&
              ((this.formId = this.getAttribute('form-id')), (this._hasChanged = !0)),
            this.elemId &&
              this.formId &&
              this._hasChanged &&
              this.isConnected &&
              this.frameReady &&
              ((this._hasChanged = !1), this.render())
        }
        generateBaseStyle(t) {
          this.parentElement.append(t),
            this.classList.length &&
              Array.from(this.classList).forEach((e) => {
                t.classList.add(e)
              })
          let r = n.getComputedStyle(t, null),
            i = {}
          return (
            Object.keys(r).forEach((e) => {
              i[e] = r[e]
            }),
            this.parentElement.removeChild(t),
            i
          )
        }
        generateOuterStyle(t, r) {
          Object.keys(t)
            .filter((e) => '-' !== e.charAt(0))
            .forEach((e) => {
              try {
                r[e] = t[e]
              } catch (e) {}
            })
        }
      }
    })({ HTMLElement: HTMLElement, document: document, window: window, MastercardEventEmitter: i })
  var a = ((e) => {
    let { appConfig: r, BaseInputElement: t, sleep: i, window: n, document: a, logger: s } = e
    return class extends t {
      constructor() {
        super()
      }
      static get observedAttributes() {
        return ['id', 'form-id', 'class']
      }
      async render() {
        for (; !1 === this.isConnected || !1 === this.frameReady; ) await i()
        var e = this.generateAutoStyleObject(),
          t = this.generateInnerStyleObject(e)
        this.innerFrame.contentWindow.postMessage(
          { eventType: 'updateStyle', data: { input: t } },
          r.frameOrigin
        ),
          this.generateOuterStyle(e, this.style)
      }
      connectedCallback() {
        this.appendChild(this.innerFrame),
          Object.assign(this.innerFrame.style, { width: '100%', height: '100%', border: 'none' })
        var e = `${r.sdkBase}/frames/parent/login-forms/${this.formId}/elements/${this.elemId}/contents.html`
        this.innerFrame.setAttribute('src', e), this.registerInputEvents()
      }
      registerInputEvents() {
        n.addEventListener('message', (e) => {
          if (e.origin !== r.frameOrigin) s.warn('Ignoring message from unknown origin')
          else
            switch (e.data.eventType) {
              case 'inputReady':
                ;(this.frameReady = !0), this.render(), this.emitter.emit('ready')
                break
              case 'inputBlur':
                if (e.data.elementId !== this.elemId) return
                this.emitter.emit('blur', e.data)
                break
              case 'inputFocus':
                e.data.elementId === this.elemId && this.emitter.emit('focus', e.data)
            }
        })
      }
      generateInnerStyleObject(e) {
        var t,
          r = [
            'backgroundColor',
            'color',
            'fontFamily',
            'fontKerning',
            'fontSize',
            'fontStretch',
            'fontWeight',
            'lineHeight',
            'letterSpacing',
            'textAlign',
            'textIndent',
            'textJustify',
            'textShadow',
            'textTransform',
            'verticalAlign',
            'writingMode'
          ],
          i = {}
        for (t in e) r.includes(t) && (i[t] = e[t])
        return i
      }
      generateAutoStyleObject() {
        var e = a.createElement('input')
        return e.setAttribute('type', 'text'), this.generateBaseStyle(e)
      }
    }
  })({
    appConfig: e,
    BaseInputElement: n,
    sleep: r,
    window: window,
    document: document,
    logger: console
  })
  n = ((e) => {
    let { appConfig: n, BaseInputElement: t, sleep: a, document: r, window: i, logger: s } = e
    return class extends t {
      constructor() {
        super()
      }
      static get observedAttributes() {
        return ['id', 'form-id', 'class']
      }
      async render() {
        for (; !1 === this.isConnected || !1 === this.frameReady; ) await a()
        var e = this.generateInputStyleObject(),
          t = this.generateRadioStyleObject(),
          r = this.generateImageStyleObject(),
          i = this.generateLabelStyleObject(),
          e = this.generateInnerStyleObject(e),
          t = this.generateInnerStyleObject(t),
          r = this.generateInnerStyleObject(r),
          i = this.generateInnerStyleObject(i),
          e =
            (this.innerFrame.contentWindow.postMessage(
              { eventType: 'updateStyle', data: { input: e, radio: t, image: r, label: i } },
              n.frameOrigin
            ),
            this.style)
        this.generateOuterStyle(e, this.style)
      }
      connectedCallback() {
        this.appendChild(this.innerFrame),
          Object.assign(this.innerFrame.style, { width: '100%', height: '100%', border: 'none' })
        var e = `${n.sdkBase}/frames/parent/mfa/${this.formId}/elements/${this.elemId}/contents.html`
        this.innerFrame.setAttribute('src', e), this.registerInputEvents()
      }
      registerInputEvents() {
        i.addEventListener('message', (e) => {
          if (e.origin !== n.frameOrigin) s.warn('Ignoring message from unknown origin')
          else
            switch (e.data.eventType) {
              case 'inputReady':
                ;(this.frameReady = !0), this.render(), this.emitter.emit('ready')
                break
              case 'inputBlur':
                if (e.data.elementId !== this.elemId) return
                this.emitter.emit('blur', e.data)
                break
              case 'inputFocus':
                e.data.elementId === this.elemId && this.emitter.emit('focus', e.data)
            }
        })
      }
      generateInnerStyleObject(e) {
        var t,
          r = [
            'height',
            'width',
            'maxHeight',
            'maxWidth',
            'backgroundColor',
            'color',
            'cursor',
            'display',
            'fontFamily',
            'fontKerning',
            'fontSize',
            'fontStretch',
            'fontWeight',
            'lineHeight',
            'letterSpacing',
            'textAlign',
            'textIndent',
            'textJustify',
            'textShadow',
            'textTransform',
            'verticalAlign',
            'writingMode',
            'paddingTop',
            'paddingLeft',
            'paddingRight',
            'paddingBottom',
            'padding',
            'zIndex',
            'position',
            'top',
            'left',
            'right',
            'bottom',
            'marginTop',
            'marginLeft',
            'marginBottom',
            'marginRight',
            'margin'
          ],
          i = {}
        for (t in e) r.includes(t) && (i[t] = e[t])
        return i
      }
      generateInputStyleObject() {
        var e = r.createElement('input')
        return (
          e.classList.add('mastercard-mfa-text-input'),
          e.setAttribute('type', 'text'),
          this.generateBaseStyle(e)
        )
      }
      generateRadioStyleObject() {
        var e = r.createElement('input')
        return (
          e.classList.add('mastercard-mfa-radio-input'),
          e.setAttribute('type', 'radio'),
          this.generateBaseStyle(e)
        )
      }
      generateImageStyleObject() {
        var e = r.createElement('div')
        return e.classList.add('mastercard-mfa-image'), this.generateBaseStyle(e)
      }
      generateLabelStyleObject() {
        var e = r.createElement('label')
        return e.classList.add('mastercard-mfa-label'), this.generateBaseStyle(e)
      }
    }
  })({
    appConfig: e,
    BaseInputElement: n,
    sleep: r,
    document: document,
    window: window,
    logger: console,
    MastercardEventEmitter: i
  })
  r = ((e) => {
    let { appConfig: r, HTMLElement: t, logger: i, document: n, window: a } = e
    return class extends t {
      constructor() {
        super(),
          (this.eventStreamId = null),
          (this.formId = null),
          (this.events = new EventTarget())
      }
      static get observedAttributes() {
        return ['event-stream-id', 'form-id']
      }
      connectedCallback() {
        var e = this
        if (
          (this.eventStreamId || (this.eventStreamId = e.getAttribute('event-stream-id')),
          !this.formId && e.getAttribute('form-id'))
        )
          this.formId = e.getAttribute('form-id')
        else if (!this.formId)
          try {
            this.formId = e.closest('mastercard-form').getAttribute('id')
          } catch (e) {
            i.error('Could not set form id: ' + e)
          }
        this.formId
          ? ((this.iframe = n.createElement('iframe')),
            e.append(this.iframe),
            (e.style.display = 'none'),
            this.eventStreamId && (this._bindFrameSource(), this._registerEventListener()))
          : i.error('Could not locate form-id')
      }
      attributeChangedCallback(e, t, r) {
        this.isConnected &&
          'event-stream-id' === e &&
          ((this.eventStreamId = r), this._bindFrameSource(), this._registerEventListener())
      }
      _bindFrameSource() {
        var e =
          `${r.sdkBase}/frames/parent/forms/event-stream.html?event-stream-id=${this.eventStreamId}&form-id=` +
          this.formId
        this.iframe.setAttribute('src', e)
      }
      _registerEventListener() {
        a.addEventListener('message', (e) => {
          if (e.origin !== r.frameOrigin) i.warn('Skipping message from ' + e.origin)
          else {
            var t = new Event(e.data.eventType)
            ;(t.data = (e.data || {}).data), (t.id = (e.data || {}).id)
            try {
              delete t.data.isPublic, delete t.data.eventType, delete t.data.id
            } catch (e) {
              i.warn(e)
            }
            this.events.dispatchEvent(t)
          }
        })
      }
      _isValidEventStreamId(e) {
        return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(e)
      }
    }
  })({
    appConfig: e,
    HTMLElement: HTMLElement,
    document: document,
    window: window,
    logger: console
  })
  customElements.define('mastercard-form', t),
    customElements.define('mastercard-input', a),
    customElements.define('mastercard-mfa-choice', n),
    customElements.define('mastercard-event-stream', r)
})()
//# sourceMappingURL=sdk.js.map
